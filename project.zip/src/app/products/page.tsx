
"use client"

import { ShoppingBag, Star, Filter, Search, ChevronDown, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';

const PRODUCTS = [
  { id: 1, name: "Gentle Foaming Cleanser", brand: "Luminex", category: "Cleanser", price: 24, rating: 4.8, target: "Acne", img: "https://picsum.photos/seed/p1/400/400" },
  { id: 2, name: "Hyaluronic Acid Serum", brand: "HydraPlus", category: "Serum", price: 42, rating: 4.9, target: "Dry Skin", img: "https://picsum.photos/seed/p2/400/400" },
  { id: 3, name: "Ultra-Light SPF 50", brand: "SolarGuard", category: "Sunscreen", price: 18, rating: 4.7, target: "Protection", img: "https://picsum.photos/seed/p3/400/400" },
  { id: 4, name: "Retinol Night Cream", brand: "AgeDefy", category: "Moisturizer", price: 65, rating: 4.6, target: "Wrinkles", img: "https://picsum.photos/seed/p4/400/400" },
  { id: 5, name: "Vitamin C Brightener", brand: "GlowLab", category: "Serum", price: 38, rating: 4.8, target: "Dark Spots", img: "https://picsum.photos/seed/p5/400/400" },
  { id: 6, name: "BHA Liquid Exfoliant", brand: "ClearPore", category: "Treatment", price: 32, rating: 4.9, target: "Oiliness", img: "https://picsum.photos/seed/p6/400/400" },
];

export default function ProductsPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-6 py-12 space-y-12">
        <header className="space-y-4">
          <h1 className="text-4xl md:text-5xl font-headline font-bold">Curated <span className="text-primary">Catalog</span></h1>
          <p className="text-muted-foreground text-lg">Smart skincare solutions for every skin type.</p>
        </header>

        <div className="flex flex-col md:flex-row gap-6 justify-between items-center glass p-4 rounded-2xl border-white/5">
          <div className="relative w-full md:max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search products, ingredients..." 
              className="pl-10 bg-white/5 border-white/10 h-12 rounded-xl focus:ring-primary/20"
            />
          </div>
          
          <div className="flex gap-4 w-full md:w-auto">
            <Button variant="outline" className="h-12 glass border-white/10 gap-2 flex-1 md:flex-none">
              <Filter className="w-4 h-4" />
              Filters
            </Button>
            <Button variant="outline" className="h-12 glass border-white/10 gap-2 flex-1 md:flex-none">
              Sort: Popular
              <ChevronDown className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {PRODUCTS.map((product) => (
            <Card key={product.id} className="glass border-white/5 group hover:border-primary/20 transition-all overflow-hidden rounded-3xl">
              <div className="aspect-square relative overflow-hidden bg-muted">
                <img 
                  src={product.img} 
                  alt={product.name} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-80"
                />
                <div className="absolute top-4 left-4">
                  <Badge className="bg-background/80 backdrop-blur-md text-foreground border-none font-bold text-[10px] tracking-widest uppercase">
                    {product.category}
                  </Badge>
                </div>
                <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                   <Button size="icon" variant="secondary" className="rounded-full shadow-xl">
                    <ShoppingBag className="w-5 h-5" />
                  </Button>
                </div>
              </div>
              <CardContent className="p-6 space-y-4">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-1">{product.brand}</p>
                    <h3 className="text-lg font-bold group-hover:text-primary transition-colors">{product.name}</h3>
                  </div>
                  <div className="flex items-center gap-1 text-yellow-500 font-black">
                    <Star className="w-4 h-4 fill-current" />
                    <span className="text-sm">{product.rating}</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                   <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-white/5 text-white/60 text-[10px] font-bold uppercase">
                    <Check className="w-3 h-3 text-primary" />
                    Target: {product.target}
                  </div>
                </div>
                
                <div className="flex justify-between items-center pt-2">
                  <p className="text-2xl font-headline font-black">${product.price}</p>
                  <Button className="bg-white/5 hover:bg-primary hover:text-background transition-all rounded-xl border-white/10 border px-6">
                    Add To Cart
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
