"use client"

import { useState, useRef, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Scan, Camera, Sparkles, RefreshCcw, ShieldCheck, ChevronRight, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { toast } from '@/hooks/use-toast';

type ScanMode = 'RGB' | 'UV' | 'Texture' | 'Oil' | 'Redness';

export default function ScannerPage() {
  const router = useRouter();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [activeMode, setActiveMode] = useState<ScanMode>('RGB');
  const [analysisCompleted, setAnalysisCompleted] = useState(false);

  useEffect(() => {
    async function initCamera() {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } } 
        });
        setStream(mediaStream);
      } catch (err) {
        console.error("Camera access denied:", err);
        toast({
          variant: "destructive",
          title: "Camera Access Error",
          description: "Please enable camera permissions to use the AI scanner."
        });
      }
    }
    initCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  // Ensure stream is attached to video element correctly
  useEffect(() => {
    if (stream && videoRef.current) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  const completeScan = useCallback(() => {
    setIsScanning(false);
    setAnalysisCompleted(true);
    
    // Store mock analysis data
    const mockData = {
      acne: Math.floor(Math.random() * 30),
      hydration: Math.floor(Math.random() * 60) + 20,
      oiliness: ['Low', 'Medium', 'High'][Math.floor(Math.random() * 3)],
      wrinkles: ['Low', 'Medium', 'High'][Math.floor(Math.random() * 3)],
      skinAge: Math.floor(Math.random() * 10) + 20,
      timestamp: new Date().toISOString()
    };
    localStorage.setItem('latest_skin_scan', JSON.stringify(mockData));
    
    toast({
      title: "Analysis Complete",
      description: "Redirecting to your results report...",
    });

    setTimeout(() => {
      router.push('/results');
    }, 1500);
  }, [router]);

  // Handle scan completion safely outside of the interval to avoid React state update warnings
  useEffect(() => {
    if (isScanning && scanProgress >= 100) {
      completeScan();
    }
  }, [scanProgress, isScanning, completeScan]);

  const runScan = () => {
    setIsScanning(true);
    setScanProgress(0);
    
    const interval = setInterval(() => {
      setScanProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 1;
      });
    }, 40);
  };

  const getFilterStyle = (mode: ScanMode) => {
    switch(mode) {
      case 'UV': return 'sepia(0.5) hue-rotate(200deg) brightness(1.2)';
      case 'Texture': return 'contrast(1.5) grayscale(1)';
      case 'Oil': return 'invert(0.1) hue-rotate(90deg) opacity(0.8)';
      case 'Redness': return 'saturate(3) hue-rotate(-20deg)';
      default: return 'none';
    }
  };

  return (
    <div className="min-h-[calc(100vh-76px)] flex flex-col items-center justify-center p-6 relative overflow-hidden bg-background">
      <div className="absolute top-1/4 right-0 w-[500px] h-[500px] bg-primary/5 blur-[150px] rounded-full pointer-events-none" />
      <div className="absolute bottom-1/4 left-0 w-[500px] h-[500px] bg-secondary/5 blur-[150px] rounded-full pointer-events-none" />

      <div className="max-w-4xl w-full space-y-8 z-10">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-headline font-bold">AI Facial Scanner</h1>
          <p className="text-muted-foreground">Keep your face within the frame for optimal analysis</p>
        </div>

        <div className="relative aspect-video glass rounded-3xl border-white/5 overflow-hidden shadow-2xl">
          <video 
            ref={videoRef} 
            autoPlay 
            playsInline 
            muted
            className="w-full h-full object-cover transition-all duration-500"
            style={{ filter: getFilterStyle(activeMode) }}
          />

          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-8 left-8 w-12 h-12 border-t-2 border-l-2 border-primary/60 rounded-tl-xl" />
            <div className="absolute top-8 right-8 w-12 h-12 border-t-2 border-r-2 border-primary/60 rounded-tr-xl" />
            <div className="absolute bottom-8 left-8 w-12 h-12 border-b-2 border-l-2 border-primary/60 rounded-bl-xl" />
            <div className="absolute bottom-8 right-8 w-12 h-12 border-b-2 border-r-2 border-primary/60 rounded-br-xl" />
            
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 border border-white/10 rounded-full flex items-center justify-center">
              <div className="w-64 h-64 border-2 border-dashed border-primary/20 rounded-full animate-[spin_10s_linear_infinite]" />
              <div className="absolute inset-0 facial-mesh opacity-10 rounded-full" />
            </div>

            {isScanning && (
              <>
                <div className="scanner-line shadow-[0_0_20px_hsl(var(--primary))]" />
                <div className="absolute inset-0 bg-primary/5 animate-pulse" />
              </>
            )}

            <div className="absolute top-6 left-1/2 -translate-x-1/2 flex items-center gap-2 px-3 py-1.5 rounded-full glass border-white/10 backdrop-blur-xl">
              <Zap className="w-4 h-4 text-primary animate-pulse" />
              <span className="text-xs font-bold tracking-widest uppercase">{activeMode} SCAN MODE</span>
            </div>
          </div>

          <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between gap-4">
            <div className="flex gap-2 glass p-1.5 rounded-2xl border-white/10">
              {(['RGB', 'UV', 'Texture', 'Oil', 'Redness'] as ScanMode[]).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setActiveMode(mode)}
                  disabled={isScanning}
                  className={`px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                    activeMode === mode 
                    ? 'bg-primary text-background' 
                    : 'hover:bg-white/5 text-white/60'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>

            {!isScanning && !analysisCompleted && (
              <Button 
                onClick={runScan}
                size="lg"
                className="bg-primary text-background hover:opacity-90 transition-opacity gap-2 px-8 rounded-2xl font-bold shadow-lg shadow-primary/20"
              >
                <Scan className="w-5 h-5" />
                Analyze Skin
              </Button>
            )}

            {isScanning && (
              <div className="flex-1 max-w-[200px] space-y-2">
                <div className="flex justify-between text-[10px] font-black tracking-tighter uppercase opacity-60">
                  <span>Extracting Features</span>
                  <span>{scanProgress}%</span>
                </div>
                <Progress value={scanProgress} className="h-2 bg-white/5" />
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <ScanTip 
            icon={<ShieldCheck className="w-5 h-5 text-primary" />}
            title="Privacy Secured"
            description="Your face data is processed locally and never stored without consent."
          />
          <ScanTip 
            icon={<Sparkles className="w-5 h-5 text-secondary" />}
            title="AI Precision"
            description="Our neural network analyzes over 2,000 distinct skin points."
          />
          <ScanTip 
            icon={<RefreshCcw className="w-5 h-5 text-primary" />}
            title="Best Results"
            description="Ensure uniform lighting and neutral expression for highest accuracy."
          />
        </div>
      </div>
    </div>
  );
}

function ScanTip({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="flex gap-4 p-5 glass rounded-2xl border-white/5">
      <div className="p-2 rounded-xl bg-white/5 h-fit">{icon}</div>
      <div className="space-y-1">
        <h3 className="text-sm font-bold">{title}</h3>
        <p className="text-xs text-muted-foreground leading-relaxed">{description}</p>
      </div>
    </div>
  );
}
