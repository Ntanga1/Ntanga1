
"use client"

import { useState, useEffect } from 'react';
import { 
  History, 
  Calendar, 
  TrendingUp, 
  ChevronRight, 
  Sparkles, 
  ArrowUpRight,
  Plus,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import Link from 'next/link';

export default function DashboardPage() {
  const [history, setHistory] = useState<any[]>([]);

  useEffect(() => {
    // Generate some mock history for demonstration
    const mockHistory = [
      { id: 1, date: '2024-05-10', score: 88, age: 24, issues: ['Mild Acne'] },
      { id: 2, date: '2024-05-03', score: 84, age: 25, issues: ['Dryness', 'Redness'] },
      { id: 3, date: '2024-04-26', score: 81, age: 25, issues: ['High Oiliness'] },
    ];
    setHistory(mockHistory);
  }, []);

  return (
    <div className="min-h-screen bg-background p-6 md:p-12">
      <div className="max-w-7xl mx-auto space-y-12">
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-1">
            <h1 className="text-4xl font-headline font-bold">Your Skin Journey</h1>
            <p className="text-muted-foreground">Monitoring your progress with AI precision.</p>
          </div>
          <Link href="/scanner">
            <Button size="lg" className="bg-primary text-background font-bold rounded-2xl gap-2 shadow-lg shadow-primary/20">
              <Plus className="w-5 h-5" />
              New Scan
            </Button>
          </Link>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Chart/Progress Area */}
          <div className="lg:col-span-2 space-y-8">
            <Card className="glass border-white/5">
              <CardHeader>
                <CardTitle className="flex justify-between items-center">
                  <span>Overall Skin Health</span>
                  <Badge variant="outline" className="border-primary/20 text-primary font-bold">
                    +7% vs Last Month
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-end justify-between gap-4 pt-8">
                  {[45, 60, 55, 75, 82, 88].map((val, i) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-2 group">
                      <div 
                        className="w-full bg-gradient-to-t from-primary/20 to-primary rounded-t-xl transition-all group-hover:opacity-80" 
                        style={{ height: `${val}%` }}
                      >
                        <div className="opacity-0 group-hover:opacity-100 transition-opacity bg-primary text-background text-[10px] font-black p-1 rounded -translate-y-6 text-center">
                          {val}%
                        </div>
                      </div>
                      <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">Wk {i+1}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <Card className="glass border-white/5 bg-gradient-to-br from-secondary/5 to-transparent">
                <CardContent className="p-8 space-y-4">
                   <div className="w-12 h-12 rounded-2xl bg-secondary/20 flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-secondary" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-3xl font-headline font-black">Hydration +12%</p>
                    <p className="text-sm text-muted-foreground">Your recent routine is showing great results for dryness.</p>
                  </div>
                </CardContent>
              </Card>
               <Card className="glass border-white/5">
                <CardContent className="p-8 space-y-4">
                   <div className="w-12 h-12 rounded-2xl bg-primary/20 flex items-center justify-center">
                    <Sparkles className="w-6 h-6 text-primary" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-3xl font-headline font-black">24 Skin Age</p>
                    <p className="text-sm text-muted-foreground">Biological skin age is trending 4 years below actual age.</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* History Sidebar */}
          <div className="space-y-6">
            <h2 className="text-xl font-headline font-bold flex items-center gap-2">
              <History className="w-5 h-5 text-muted-foreground" />
              Recent Scans
            </h2>
            <div className="space-y-4">
              {history.map((scan) => (
                <div key={scan.id} className="p-5 glass rounded-2xl border-white/5 hover:border-primary/20 transition-all cursor-pointer group">
                  <div className="flex justify-between items-start mb-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs text-muted-foreground font-bold uppercase tracking-widest">
                        <Calendar className="w-3 h-3" />
                        {new Date(scan.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      </div>
                      <h3 className="font-bold">Health Score: <span className="text-primary">{scan.score}%</span></h3>
                    </div>
                    <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:translate-x-1 transition-transform" />
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {scan.issues.map((issue: string, idx: number) => (
                      <Badge key={idx} variant="secondary" className="bg-white/5 text-white/60 text-[10px] font-bold border-none uppercase">
                        {issue}
                      </Badge>
                    ))}
                  </div>
                </div>
              ))}
              <Button variant="ghost" className="w-full text-muted-foreground hover:text-white gap-2">
                View Full History
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Badge({ children, variant = "default", className = "" }: any) {
  const variants: any = {
    default: "bg-primary text-background",
    secondary: "bg-secondary text-white",
    outline: "border border-white/20 text-white"
  };
  return (
    <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-widest ${variants[variant]} ${className}`}>
      {children}
    </span>
  );
}
