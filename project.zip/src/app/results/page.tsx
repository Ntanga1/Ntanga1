"use client"

import { useState, useEffect } from 'react';
import { 
  aiSkinAnalysisSummary, 
  type AISkinAnalysisSummaryOutput 
} from '@/ai/flows/ai-skin-analysis-summary';
import { 
  recommendSkincareProducts, 
  type ProductRecommendationOutput 
} from '@/ai/flows/ai-product-recommendations';
import { 
  CheckCircle2, 
  AlertCircle, 
  Activity, 
  Calendar, 
  ArrowRight, 
  ShoppingBag,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from '@/components/ui/skeleton';

export default function ResultsPage() {
  const [scanData, setScanData] = useState<any>(null);
  const [summary, setSummary] = useState<string | null>(null);
  const [recommendations, setRecommendations] = useState<ProductRecommendationOutput | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const data = localStorage.getItem('latest_skin_scan');
    if (data) {
      const parsed = JSON.parse(data);
      setScanData(parsed);
      generateAIContent(parsed);
    } else {
      setLoading(false);
    }
  }, []);

  const generateAIContent = async (data: any) => {
    try {
      // Step 1: Get AI Summary
      const summaryResult = await aiSkinAnalysisSummary({
        skinAnalysisData: {
          acne: data.acne,
          hydration: data.hydration,
          oiliness: data.oiliness,
          wrinkles: data.wrinkles,
          skinAge: data.skinAge,
        }
      });
      setSummary(summaryResult.summary);

      // Step 2: Get Product Recommendations
      const recommendationResult = await recommendSkincareProducts({
        skinAnalysisSummary: summaryResult.summary
      });
      setRecommendations(recommendationResult);
    } catch (err) {
      console.error("AI Generation error:", err);
    } finally {
      setLoading(false);
    }
  };

  if (!scanData && !loading) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="text-center space-y-4">
          <AlertCircle className="w-16 h-16 text-muted-foreground mx-auto" />
          <h2 className="text-2xl font-headline font-bold">No Scan Data Found</h2>
          <p className="text-muted-foreground">Please complete a skin scan to see results.</p>
          <Button onClick={() => window.location.href = '/scanner'}>Go to Scanner</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6 md:p-12">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header Section */}
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-black uppercase tracking-widest">
              Scan Complete
            </div>
            <h1 className="text-4xl md:text-5xl font-headline font-bold">Your Skin Report</h1>
            <p className="text-muted-foreground flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              {scanData ? new Date(scanData.timestamp).toLocaleDateString('en-US', { dateStyle: 'long' }) : '...'}
            </p>
          </div>
          
          <div className="flex items-center gap-4 glass p-4 rounded-2xl border-white/5">
            <div className="text-right">
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Estimated Skin Age</p>
              <p className="text-3xl font-headline font-black text-primary">{scanData?.skinAge || '--'} Years</p>
            </div>
            <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
              <Activity className="w-6 h-6 text-primary" />
            </div>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Stats Column */}
          <div className="lg:col-span-2 space-y-8">
            <Card className="glass border-white/5 overflow-hidden">
              <CardHeader className="border-b border-white/5">
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-primary" />
                  AI Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                {loading ? (
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-[90%]" />
                    <Skeleton className="h-4 w-[95%]" />
                  </div>
                ) : (
                  <p className="text-lg leading-relaxed text-foreground/90 italic font-medium">
                    "{summary}"
                  </p>
                )}
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <StatItem label="Acne Score" value={scanData?.acne} unit="%" color="destructive" inverse />
              <StatItem label="Hydration" value={scanData?.hydration} unit="%" color="primary" />
              <StatItem label="Oiliness" status={scanData?.oiliness} />
              <StatItem label="Wrinkles" status={scanData?.wrinkles} />
            </div>
          </div>

          {/* Side Recommendations Column */}
          <div className="space-y-8">
            <div className="glass rounded-3xl p-8 border-white/5 space-y-6 relative overflow-hidden">
               <div className="absolute top-0 right-0 w-24 h-24 bg-secondary/10 blur-2xl rounded-full" />
               <h2 className="text-2xl font-headline font-bold flex items-center gap-2">
                <ShoppingBag className="w-6 h-6 text-secondary" />
                Recommended Care
              </h2>
              
              <div className="space-y-4">
                {loading ? (
                   Array.from({ length: 3 }).map((_, i) => (
                    <div key={i} className="flex gap-4 p-4 glass rounded-2xl border-white/5">
                      <Skeleton className="w-16 h-16 rounded-xl shrink-0" />
                      <div className="space-y-2 flex-1">
                        <Skeleton className="h-4 w-3/4" />
                        <Skeleton className="h-3 w-1/2" />
                      </div>
                    </div>
                  ))
                ) : (
                  recommendations?.recommendations.map((item, idx) => (
                    <div key={idx} className="group p-4 glass rounded-2xl border-white/5 hover:border-secondary/30 transition-all cursor-pointer">
                      <div className="flex justify-between items-start mb-2">
                        <Badge variant="secondary" className="bg-secondary/10 text-secondary border-none text-[10px] font-black uppercase tracking-tighter">
                          {item.category}
                        </Badge>
                        <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-secondary transition-transform group-hover:translate-x-1" />
                      </div>
                      <h3 className="font-bold text-sm mb-1">{item.productName}</h3>
                      <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed">
                        {item.reason}
                      </p>
                      <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between">
                         <span className="text-[10px] text-muted-foreground font-bold tracking-widest uppercase">Key: {item.keyIngredients}</span>
                         <Button variant="link" size="sm" className="h-auto p-0 text-primary text-xs">Add to Cart</Button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              <Button className="w-full bg-secondary text-white hover:opacity-90 py-6 rounded-2xl text-lg font-bold gap-2">
                View Full Catalog
                <ArrowRight className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatItem({ label, value, unit, status, color = "primary", inverse = false }: any) {
  const getProgressColor = () => {
    if (inverse) {
      return value > 50 ? 'bg-destructive' : 'bg-green-500';
    }
    return `bg-${color}`;
  };

  return (
    <div className="p-6 glass rounded-2xl border-white/5 space-y-4">
      <div className="flex justify-between items-end">
        <span className="text-sm font-bold text-muted-foreground uppercase tracking-wider">{label}</span>
        {status ? (
          <Badge className={`${status === 'High' ? 'bg-orange-500' : status === 'Medium' ? 'bg-yellow-500' : 'bg-green-500'} text-white`}>
            {status}
          </Badge>
        ) : (
          <span className="text-2xl font-headline font-black text-white">{value}{unit}</span>
        )}
      </div>
      {!status && (
        <Progress value={value} className="h-2 bg-white/5" />
      )}
    </div>
  );
}
