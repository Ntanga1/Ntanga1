
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { 
  Scan, 
  Activity, 
  Sparkles, 
  History, 
  CheckCircle2, 
  ShieldCheck, 
  Smartphone, 
  ArrowRight 
} from 'lucide-react';

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden py-20 px-6">
        <div className="absolute inset-0 facial-mesh opacity-20" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/20 blur-[120px] rounded-full" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-secondary/10 blur-[100px] rounded-full" />
        
        <div className="relative z-10 max-w-5xl mx-auto text-center space-y-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border-primary/20 text-primary text-sm font-medium animate-pulse">
            <Sparkles className="w-4 h-4" />
            <span>Next-Gen Skincare Intelligence</span>
          </div>
          
          <h1 className="font-headline text-5xl md:text-7xl font-bold leading-tight tracking-tight">
            Scan Your Skin with <br />
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">AI Technology</span>
          </h1>
          
          <p className="text-muted-foreground text-lg md:text-xl max-w-2xl mx-auto font-body">
            Professional-grade skin analysis directly in your browser. Detect issues, track progress, and get personalized recommendations in seconds.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/scanner">
              <Button size="lg" className="h-14 px-8 bg-gradient-to-r from-primary to-secondary text-white text-lg font-bold border-none hover:scale-105 transition-transform gap-2">
                <Scan className="w-6 h-6" />
                Start Live Scan
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="h-14 px-8 glass border-white/10 text-lg hover:bg-white/5">
              Learn How It Works
            </Button>
          </div>
        </div>

        {/* Animated Scanner Visual */}
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-full max-w-lg aspect-square glass rounded-t-full opacity-30 border-t-2 border-primary overflow-hidden">
          <div className="scanner-line" />
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 px-6 bg-card/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-4 mb-16">
            <h2 className="font-headline text-3xl md:text-5xl font-bold">Cutting-Edge Features</h2>
            <p className="text-muted-foreground">The ultimate skincare companion powered by computer vision.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard 
              icon={<Scan className="w-8 h-8 text-primary" />}
              title="AI Analysis"
              description="Instantly detect acne, wrinkles, pigmentation, and more with 98% accuracy."
            />
            <FeatureCard 
              icon={<Activity className="w-8 h-8 text-secondary" />}
              title="Real-Time Scanning"
              description="Dynamic overlays and heatmaps show your skin health as it happens."
            />
            <FeatureCard 
              icon={<Sparkles className="w-8 h-8 text-primary" />}
              title="Smart Recommendations"
              description="Get product suggestions based on your specific skin chemistry and concerns."
            />
            <FeatureCard 
              icon={<History className="w-8 h-8 text-secondary" />}
              title="Progress Tracking"
              description="Save your scans and watch your skin improve with historical comparisons."
            />
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <h2 className="font-headline text-4xl md:text-5xl font-bold">Simple. Fast. Precise.</h2>
              <div className="space-y-6">
                <Step 
                  number="01" 
                  title="Open Camera" 
                  description="Grant access to your device camera securely from any browser." 
                />
                <Step 
                  number="02" 
                  title="AI Scan" 
                  description="Our algorithm maps your facial features and analyzes every pore." 
                />
                <Step 
                  number="03" 
                  title="Get Report" 
                  description="Receive a comprehensive health score and detailed condition breakdown." 
                />
                <Step 
                  number="04" 
                  title="Improvement" 
                  description="Follow recommendations and track your progress weekly." 
                />
              </div>
            </div>
            <div className="relative">
              <div className="aspect-[4/5] glass rounded-3xl p-2 border-primary/20">
                <img 
                  src="https://picsum.photos/seed/face-scan/800/1000" 
                  alt="AI Scanning Preview" 
                  className="rounded-2xl w-full h-full object-cover grayscale opacity-80"
                  data-ai-hint="scanning face"
                />
                <div className="absolute inset-4 scanner-line opacity-50" />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 border-2 border-primary rounded-full animate-ping" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-white/5 bg-background">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
             <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Scan className="text-background w-5 h-5" />
            </div>
            <span className="font-headline font-bold text-xl tracking-tight">
              ClarityScan <span className="text-primary">AI</span>
            </span>
          </div>
          
          <div className="flex gap-8 text-sm text-muted-foreground font-medium">
            <Link href="/privacy" className="hover:text-primary transition-colors">Privacy Policy</Link>
            <Link href="/terms" className="hover:text-primary transition-colors">Terms of Service</Link>
            <Link href="/contact" className="hover:text-primary transition-colors">Contact Us</Link>
          </div>
          
          <p className="text-xs text-muted-foreground">© 2024 ClarityScan AI. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="p-8 glass rounded-2xl border-white/5 hover:border-primary/20 transition-all group">
      <div className="mb-6 p-3 w-fit rounded-xl bg-muted group-hover:bg-primary/10 transition-colors">
        {icon}
      </div>
      <h3 className="font-headline text-xl font-bold mb-3">{title}</h3>
      <p className="text-muted-foreground text-sm leading-relaxed">{description}</p>
    </div>
  );
}

function Step({ number, title, description }: { number: string, title: string, description: string }) {
  return (
    <div className="flex gap-6 items-start">
      <div className="text-4xl font-headline font-black text-white/10 select-none">{number}</div>
      <div>
        <h4 className="font-headline text-xl font-bold mb-1">{title}</h4>
        <p className="text-muted-foreground text-sm">{description}</p>
      </div>
    </div>
  );
}
