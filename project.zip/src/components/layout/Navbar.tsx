
"use client"

import Link from 'next/link'
import { Scan, User, ShoppingBag, LayoutDashboard, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function Navbar() {
  return (
    <nav className="sticky top-0 z-50 glass border-b border-white/5 px-6 py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-lg shadow-primary/20">
            <Scan className="text-white w-6 h-6" />
          </div>
          <span className="font-headline font-bold text-xl tracking-tight hidden sm:block">
            ClarityScan <span className="text-primary">AI</span>
          </span>
        </Link>

        <div className="flex items-center gap-4 sm:gap-8">
          <Link href="/products" className="text-sm font-medium hover:text-primary transition-colors flex items-center gap-2">
            <ShoppingBag className="w-4 h-4" />
            <span className="hidden md:inline">Products</span>
          </Link>
          <Link href="/dashboard" className="text-sm font-medium hover:text-primary transition-colors flex items-center gap-2">
            <LayoutDashboard className="w-4 h-4" />
            <span className="hidden md:inline">Dashboard</span>
          </Link>
          <Link href="/scanner">
            <Button className="bg-gradient-to-r from-primary to-secondary text-white border-none hover:opacity-90 transition-opacity gap-2">
              <Sparkles className="w-4 h-4" />
              <span>Start Scan</span>
            </Button>
          </Link>
          <Link href="/auth">
            <div className="w-9 h-9 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors">
              <User className="w-5 h-5" />
            </div>
          </Link>
        </div>
      </div>
    </nav>
  )
}
