'use server';
/**
 * @fileOverview This file implements a Genkit flow for summarizing AI skin analysis results.
 *
 * - aiSkinAnalysisSummary - A function that generates a concise summary of skin conditions.
 * - AISkinAnalysisSummaryInput - The input type for the aiSkinAnalysisSummary function.
 * - AISkinAnalysisSummaryOutput - The return type for the aiSkinAnalysisSummary function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AISkinAnalysisSummaryInputSchema = z.object({
  skinAnalysisData: z.object({
    acne: z.number().describe('The percentage or score indicating acne severity (0-100).'),
    hydration: z.number().describe('The percentage or score indicating skin hydration level (0-100).'),
    oiliness: z.enum(['Low', 'Medium', 'High']).describe('The oiliness level of the skin.'),
    wrinkles: z.enum(['Low', 'Medium', 'High']).describe('The severity of wrinkles on the skin.'),
    skinAge: z.number().describe('The estimated biological age of the skin in years.'),
    darkSpots: z.number().optional(),
    fineLines: z.enum(['Low', 'Medium', 'High']).optional(),
    poreSize: z.enum(['Small', 'Medium', 'Large']).optional(),
    redness: z.number().optional(),
    unevenSkinTone: z.number().optional(),
    darkCircles: z.number().optional()
  })
});

export type AISkinAnalysisSummaryInput = z.infer<typeof AISkinAnalysisSummaryInputSchema>;

const AISkinAnalysisSummaryOutputSchema = z.object({
  summary: z.string().describe('A concise summary of the user\'s skin conditions.')
});

export type AISkinAnalysisSummaryOutput = z.infer<typeof AISkinAnalysisSummaryOutputSchema>;

export async function aiSkinAnalysisSummary(input: AISkinAnalysisSummaryInput): Promise<AISkinAnalysisSummaryOutput> {
  return aiSkinAnalysisSummaryFlow(input);
}

const skinAnalysisSummaryPrompt = ai.definePrompt({
  name: 'skinAnalysisSummaryPrompt',
  input: { schema: AISkinAnalysisSummaryInputSchema },
  output: { schema: AISkinAnalysisSummaryOutputSchema },
  config: {
    safetySettings: [
      {
        category: 'HARM_CATEGORY_DANGEROUS_CONTENT',
        threshold: 'BLOCK_NONE',
      },
      {
        category: 'HARM_CATEGORY_HARASSMENT',
        threshold: 'BLOCK_NONE',
      }
    ],
  },
  prompt: `You are an expert dermatologist and skincare AI assistant. Your task is to provide a clear, concise, and easy-to-understand summary of a user's skin analysis report.

Analyze the provided skin analysis data and identify the most prominent skin conditions, their severity, and any general observations about the user's skin health. Focus on explaining what the numbers mean in simple terms and highlighting key areas that need attention.

Skin Analysis Report:
- Acne Severity: {{skinAnalysisData.acne}}%
- Hydration Level: {{skinAnalysisData.hydration}}%
- Oiliness: {{skinAnalysisData.oiliness}}
- Wrinkles: {{skinAnalysisData.wrinkles}}
- Skin Age: {{skinAnalysisData.skinAge}} years

Provide a summary that is 3-5 sentences long.`
});

const aiSkinAnalysisSummaryFlow = ai.defineFlow(
  {
    name: 'aiSkinAnalysisSummaryFlow',
    inputSchema: AISkinAnalysisSummaryInputSchema,
    outputSchema: AISkinAnalysisSummaryOutputSchema
  },
  async (input) => {
    const { output } = await skinAnalysisSummaryPrompt(input);
    if (!output) {
      throw new Error('Failed to generate skin analysis summary.');
    }
    return output;
  }
);
