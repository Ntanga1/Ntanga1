'use server';
/**
 * @fileOverview An AI agent that recommends skincare products based on a skin analysis summary.
 *
 * - recommendSkincareProducts - A function that handles the skincare product recommendation process.
 * - ProductRecommendationInput - The input type for the recommendSkincareProducts function.
 * - ProductRecommendationOutput - The return type for the recommendSkincareProducts function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ProductRecommendationInputSchema = z.object({
  skinAnalysisSummary: z
    .string()
    .describe(
      'A summary of the user\'s skin analysis, detailing detected conditions and areas of concern.'
    ),
});
export type ProductRecommendationInput = z.infer<
  typeof ProductRecommendationInputSchema
>;

const ProductRecommendationOutputSchema = z.object({
  recommendations: z.array(
    z.object({
      productName: z.string().describe('The name of the recommended product.'),
      category: z
        .string()
        .describe(
          'The category of the product (e.g., Cleanser, Serum, Moisturizer, SPF).'
        ),
      keyIngredients: z
        .string()
        .describe('Key active ingredients in the product (e.g., Salicylic Acid, Hyaluronic Acid).'),
      reason: z
        .string()
        .describe(
          'A detailed explanation of why this product is suitable for the user\'s skin concerns.'
        ),
    })
  ),
});
export type ProductRecommendationOutput = z.infer<
  typeof ProductRecommendationOutputSchema
>;

export async function recommendSkincareProducts(
  input: ProductRecommendationInput
): Promise<ProductRecommendationOutput> {
  return recommendSkincareProductsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'skincareProductRecommendationPrompt',
  input: {schema: ProductRecommendationInputSchema},
  output: {schema: ProductRecommendationOutputSchema},
  prompt: `You are an expert skincare consultant. Your task is to recommend specific skincare products based on a user's skin analysis summary.

For each recommendation, provide the product name, its category (e.g., Cleanser, Serum, Moisturizer, SPF), key active ingredients, and a detailed explanation of why it is suitable for the user's detected skin conditions. Aim for 3-5 distinct product recommendations.

Use the following skin analysis summary to inform your recommendations:

Skin Analysis Summary: {{{skinAnalysisSummary}}}`,
});

const recommendSkincareProductsFlow = ai.defineFlow(
  {
    name: 'recommendSkincareProductsFlow',
    inputSchema: ProductRecommendationInputSchema,
    outputSchema: ProductRecommendationOutputSchema,
  },
  async (input) => {
    const {output} = await prompt(input);
    return output!;
  }
);
