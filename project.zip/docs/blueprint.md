# **App Name**: ClarityScan AI

## Core Features:

- AI Facial Scanning Interface: Enables users to capture real-time facial data via webcam/phone camera, with live face detection, AI scanning animations, and support for multi-mode scanning (RGB, UV, Texture, Oil, Redness).
- Comprehensive Skin Analysis & Reporting: AI analyzes scanned data across various modes to detect skin conditions like acne, wrinkles, and oiliness. Generates a detailed skin report dashboard with scores, graphs, and an AI-tool-generated summary of findings.
- Personalized Product Recommendations: An AI system suggests specific skincare products tailored to the user's unique skin concerns identified in the analysis.
- Product Catalog & Display: A curated catalog of recommended products with details and images, stored in a PostgreSQL database, allowing users to view products relevant to their analysis.
- User Authentication & Dashboard: Secure account creation (Email/Password, Google, Apple) via Firebase authentication, and a personal dashboard where users can view their past scan results and track their skin journey, with data stored in PostgreSQL.
- Skin Progress Tracking: Functionality for users to save multiple skin analysis reports and visualize changes and improvements in their skin condition over time through comparative graphs, with data stored in PostgreSQL.

## Style Guidelines:

- Dark scheme with a focus on neon blues and vibrant purples for a futuristic tech aesthetic. Primary: Neon Blue (#73E3FF) for interactive elements and highlights. Background: Deep charcoal with a subtle blue hint (#1A1D1F) to evoke sophistication and allow vibrant elements to pop. Accent: Electric Purple (#7F4CFF) for contrast and to represent transformative beauty technology.
- Headline font: 'Space Grotesk' (sans-serif) for its modern, techy, and slightly computerized feel, ideal for prominent titles. Body font: 'Inter' (sans-serif) for its readability and neutral, objective aesthetic, suitable for detailed reports and user interface text.
- Minimalist, geometric line icons, enhanced with neon glow effects or subtle blue-to-purple gradients, to convey advanced technology and scientific precision.
- Clean, dark-themed layouts featuring ample negative space and a modular grid system to ensure responsiveness across desktop and mobile devices. Incorporate elements of glassmorphism for layered depth, especially on interactive dashboards and report pages. The landing page hero section will feature a prominent, animated scanner interface.
- Dynamic AI scanning effects, live facial mesh animations, and fluid UI transitions to provide an immersive and futuristic user experience. Use animated gradients and glowing effects to emphasize key data visualizations and interactive components throughout the application.